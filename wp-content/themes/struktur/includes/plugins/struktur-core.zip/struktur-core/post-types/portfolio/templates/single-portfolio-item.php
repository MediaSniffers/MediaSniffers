<?php

get_header();

struktur_select_get_title();

do_action('struktur_select_action_before_main_content');

struktur_core_get_single_portfolio();

get_footer();