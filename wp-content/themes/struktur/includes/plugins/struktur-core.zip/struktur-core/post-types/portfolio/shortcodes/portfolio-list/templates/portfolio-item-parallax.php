<article class="qodef-pli qodef-parallax-section-holder" style="background-image: url('<?php the_post_thumbnail_url( 'full' ); ?>');" data-qodef-parallax-speed="1">
    <a href="<?php echo esc_url( $this_object->getItemLink() ); ?>" class="qodef-parallax-section-link"></a>
</article>