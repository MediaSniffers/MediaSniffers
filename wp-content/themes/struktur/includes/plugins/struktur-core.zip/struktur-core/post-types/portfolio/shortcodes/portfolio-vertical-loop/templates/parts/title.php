<div itemprop="name" class="qodef-pvli-title entry-title">
    <?php echo esc_attr(get_the_title()); ?>
</div>
