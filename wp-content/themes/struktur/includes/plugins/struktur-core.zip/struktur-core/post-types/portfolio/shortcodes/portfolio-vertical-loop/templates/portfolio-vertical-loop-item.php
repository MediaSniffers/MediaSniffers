<article class="qodef-pvl-item <?php echo esc_attr( $this_object->getArticleClasses() ); ?>">
	<div class="qodef-pvl-item-inner">
		<?php echo struktur_core_get_cpt_shortcode_module_template_part( 'portfolio', 'portfolio-vertical-loop', 'layout-collections/standard', '', $params, $additional_params ); ?>
    </div>
</article>