<?php

include_once STRUKTUR_CORE_SHORTCODES_PATH . '/horizontal-layout/functions.php';
include_once STRUKTUR_CORE_SHORTCODES_PATH . '/horizontal-layout/horizontal-layout.php';