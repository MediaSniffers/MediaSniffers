<?php

include_once STRUKTUR_CORE_SHORTCODES_PATH . '/outline-text/functions.php';
include_once STRUKTUR_CORE_SHORTCODES_PATH . '/outline-text/outline-text.php';