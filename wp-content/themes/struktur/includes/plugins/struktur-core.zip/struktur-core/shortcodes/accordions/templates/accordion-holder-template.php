<div class="qodef-accordion-holder qodef-ac-simple <?php echo esc_attr($holder_classes); ?> clearfix">
	<?php echo do_shortcode($content); ?>
</div>