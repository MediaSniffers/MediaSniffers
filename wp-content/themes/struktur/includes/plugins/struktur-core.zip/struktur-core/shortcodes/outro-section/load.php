<?php

include_once STRUKTUR_CORE_SHORTCODES_PATH . '/outro-section/functions.php';
include_once STRUKTUR_CORE_SHORTCODES_PATH . '/outro-section/outro-section.php';