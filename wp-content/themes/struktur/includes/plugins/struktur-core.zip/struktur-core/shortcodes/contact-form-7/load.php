<?php

include_once STRUKTUR_CORE_SHORTCODES_PATH . '/contact-form-7/functions.php';
