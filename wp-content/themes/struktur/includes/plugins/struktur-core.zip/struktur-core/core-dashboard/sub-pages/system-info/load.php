<?php

include_once STRUKTUR_CORE_ABS_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';